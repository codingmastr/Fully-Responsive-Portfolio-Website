$('.menu-btn').click(function(){
  $('.navbar.menu'.toggleClass('active'));
  $('.menu-btn i').toggleClass('active');
});